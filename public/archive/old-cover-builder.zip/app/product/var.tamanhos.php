
<?php
$mh2=0;
$mw2=0;
$mh15a=0;
$mw15a=0;
$mh15b=0;
$mw15b=0;

$qm=$_GET["m"];
$ql=$_GET["l"];

switch ($qm) {
    //IPHONE4 IPHONE4S
    case 0:
        $mimage = "mask-iphone4.png";
        $mw = "340";
        $mh = "490";
        break;

    //IPHONE5
    case 1:
        $mimage = "mask-iphone5.png";
        $mw = "340";
        $mh = "534";
        break;

    //GALAXYS3
    case 2:
        $mimage = "mask-galaxy3.png";
        $mw = "340";
        $mh = "527";
        break;

    //GALAXYS4
    case 3:
        $mimage = "mask-galaxy4.png";
        $mw = "340";
        $mh = "499";
        break;

    //GALAXYS2
    case 4:
        $mimage = "mask-galaxys2.png";
        $mw = "340";
        $mh = "560";
        break;

    //GALAXY NOTE 2
    case 5:
        $mimage = "mask-galaxyn2.png";
        $mw = "340";
        $mh = "561";
        break;
}

switch ($ql) {
    //Layout 2 fotos
    case 1:
			switch ($qm) {
			    //IPHONE4 IPHONE4S
			    case 0:
			        $mw2 = "338";
			        $mh2 = "243";
			        break;

			    //IPHONE5
			    case 1:
			        $mw2 = "338";
			        $mh2 = "267";
			        break;

			    //GALAXYS3
			    case 2:
			        $mw2 = "338";
			        $mh2 = "261";
			        break;

			    //GALAXYS4
			    case 3:
			        $mw2 = "338";
			        $mh2 = "247";
			        break;

                //GALAXYS2
                case 4:
                    $mw2 = "338";
                    $mh2 = "278";
                    break;

                //GALAXY NOTE 2
                case 5:
                    $mw2 = "338";
                    $mh2 = "278";
                    break;
			}
        break;

    //Layout 15 fotos
    case 2:
                        switch ($qm) {
                            //IPHONE4 IPHONE4S
                            case 0:
                                $mw15a = "168";
                                $mh15a = "161";
                                $mw15b = "83";
                                $mh15b = "79";
                                break;

                            //IPHONE5
                            case 1:
                                $mw15a = "168";
                                $mh15a = "177";
                                $mw15b = "83";
                                $mh15b = "87";
                                break;

                            //GALAXYS3
                            case 2:
                                $mw15a = "168";
                                $mh15a = "173";
                                $mw15b = "83";
                                $mh15b = "85";
                                break;

                            //GALAXYS4
                            case 3:
                                $mw15a = "168";
                                $mh15a = "164";
                                $mw15b = "83";
                                $mh15b = "81";
                                break;

                            //GALAXYS2
                            case 4:
                                $mw15a = "168";
                                $mh15a = "184";
                                $mw15b = "83";
                                $mh15b = "91";
                                break;

                            //GALAXY NOTE 2
                            case 5:
                                $mw15a = "168";
                                $mh15a = "184";
                                $mw15b = "83";
                                $mh15b = "91";
                                break;
			}
        break;
    }

?>