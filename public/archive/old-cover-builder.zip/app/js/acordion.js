
//Load
$(function() {
  $( "#accordion" ).accordion();
});

//Passo 1
function goto1() {
  $( "#accordion" ).accordion( "option", "active", 0 );
}

//Passo 2
function goto2() {
  $( "#accordion" ).accordion( "option", "active", 1 );
}

//Passo 3
function goto3() {
  $( "#accordion" ).accordion( "option", "active", 2 );
}

//Passo 4
function goto4() {
  $( "#accordion" ).accordion( "option", "active", 3 );
}

//Passo 5
function goto5() {
  $( "#accordion" ).accordion( "option", "active", 4 );
}