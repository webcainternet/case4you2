<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = 'Feed de Produtos';
$_['text_success']     = 'Módulo Google Base modificado com sucesso!';

// Entry
$_['entry_status']     = 'Situação:';
$_['entry_data_feed']  = 'URL do Feed:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Google Base!';
?>