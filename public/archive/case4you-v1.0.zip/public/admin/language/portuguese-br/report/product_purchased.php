<?php
// Heading
$_['heading_title']     = 'Relatório de Produtos Comprados';

// Text
$_['text_all_status']   = 'Todas as Situações';

// Column
$_['column_date_start'] = 'Data Inicial';
$_['column_date_end']   = 'Data Final';
$_['column_name']       = 'Produto';
$_['column_model']      = 'Modelo';
$_['column_quantity']   = 'Quantidade';
$_['column_total']      = 'Total';

// Entry
$_['entry_date_start']  = 'Início:';
$_['entry_date_end']    = 'Fim:';
$_['entry_status']      = 'Situação:';
?>