<?php
// Heading
$_['heading_title']    = 'Relatório de Cupons';

// Column
$_['column_name']      = 'Cupom';
$_['column_code']      = 'Código';
$_['column_orders']    = 'Pedidos';
$_['column_total']     = 'Total';
$_['column_action']    = 'Ação';

// Entry
$_['entry_date_start'] = 'Início:';
$_['entry_date_end']   = 'Fim:';
?>