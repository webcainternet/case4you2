<?php
// Heading
$_['heading_title']    = 'Pontos de Fidelidade';

// Text
$_['text_total']       = 'Finalização do Pedido';
$_['text_success']     = 'Módulo Pontos de Fidelidade modificado com sucesso!';

// Entry
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem de Exibição:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Pontos de Fidelidade!';
?>