<?php
// Heading
$_['heading_title']    = 'Retirada na Loja';

// Text 
$_['text_shipping']    = 'Formas de Envio';
$_['text_success']     = 'Módulo Retirada na Loja modificado com sucesso!';

// Entry
$_['entry_geo_zone']   = 'Região Geográfica:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem de Exibição:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o módulo Retirada na Loja!';
?>