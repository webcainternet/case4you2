<?php
// Heading
$_['heading_title']   = 'Permissão Negada!'; 

// Text
$_['text_permission'] = 'Você não tem premissão para acessar esta página, entre em contato com a administração da loja.';
?>