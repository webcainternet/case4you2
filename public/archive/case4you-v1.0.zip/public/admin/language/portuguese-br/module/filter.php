<?php
// Heading
$_['heading_title']       = 'Filtros'; 

// Text
$_['text_module']         = 'M�dulos';
$_['text_success']        = 'M�dulo Filtros modificado com sucesso!';
$_['text_content_top']    = 'Topo do Conte�do';
$_['text_content_bottom'] = 'Rodap� do Conte�do';
$_['text_column_left']    = 'Coluna da Esquerda';
$_['text_column_right']   = 'Coluna da Direita';

// Entry
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Posi��o:';
$_['entry_status']        = 'Situa��o:';
$_['entry_sort_order']    = 'Ordem de Exibi��o:';

// Error
$_['error_permission']    = 'Aten��o: Voc� n�o possui permiss�o para modificar o m�dulo Filtros!';
?>