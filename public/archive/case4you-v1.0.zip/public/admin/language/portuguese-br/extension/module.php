<?php
// Heading
$_['heading_title']	   = 'Módulos';
$_['text_confirm']	   = 'Confirmar';

// Text
$_['text_install']	   = 'Instalar';
$_['text_uninstall']   = 'Desinstalar';

// Column
$_['column_name']	   = 'Módulo';
$_['column_action']	   = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os módulos!';
?>